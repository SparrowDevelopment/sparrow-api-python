# Sparrow API for Python

# Installation

`pip install sparrow`


# Running Tests

`pytest`

